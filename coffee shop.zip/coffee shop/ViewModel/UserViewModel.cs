﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using coffee_shop.Models;

namespace coffee_shop.ViewModel
{
    public class UserViewModel
    {
        public User user { get; set; }

        public List<User> Myusers { get; set; }

    }
}