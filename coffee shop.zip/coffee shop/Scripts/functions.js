﻿function myCoolFunction(){
    alert( "pop" );
}
