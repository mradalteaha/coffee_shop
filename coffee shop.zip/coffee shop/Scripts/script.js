﻿function myFunction() {

    alert("clicked");
    return true;
}