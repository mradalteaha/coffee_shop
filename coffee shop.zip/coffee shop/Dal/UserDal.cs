﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using coffee_shop.Models;

namespace coffee_shop.Dal
{
    public class UserDal:DbContext
    {
       

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<User>().ToTable("tblUser");
               
        }
        public DbSet<User> Users { get; set; }

    }
}