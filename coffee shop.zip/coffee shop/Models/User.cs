﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace coffee_shop.Models
{
    public class User
    {
        [Key]
        [Required]
        [RegularExpression("^[0-9]{9}$", ErrorMessage = "ID must be numbers ,and 9 digits")]
        public string ID { get; set; }

        [Required]
        public string firstName { get; set; }

        [Required]
        public string lastName { get; set; }


        [Required]
        public string Email { get; set; }

        [Required]
        public string Passwod { get; set; }

        [Required]
        [RegularExpression("^[0-9]{10}$", ErrorMessage = "Phone number must be 10 digits")]
        public string Phonenumber { get; set; }

        [StringLength(10)]
        [Required(ErrorMessage = "Please select a Role")]
        public string Roles { get; set; }
    }
}