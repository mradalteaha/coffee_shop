﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using coffee_shop.ViewModel;
using coffee_shop.Models;
using coffee_shop.Dal;
namespace coffee_shop.Controllers
{
    public class UserController : Controller
    {
       
     
      public ActionResult Register(User user)
        {
            if (ModelState.IsValid)
            {
                UserDal dal = new UserDal();
                dal.Users.Add(user);
                dal.SaveChanges();
                return View("PersonalPage", user);
            }
            else
                return View("UserRegister", user);
        }
    }
}